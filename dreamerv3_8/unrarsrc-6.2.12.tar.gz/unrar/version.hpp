#define RARVER_MAJOR     6
#define RARVER_MINOR    24
#define RARVER_BETA      0
#define RARVER_DAY       3
#define RARVER_MONTH    10
#define RARVER_YEAR   2023
