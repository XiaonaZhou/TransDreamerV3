#ifndef _RAR_VOLUME_
#define _RAR_VOLUME_

bool MergeArchive(Archive &Arc,ComprDataIO *DataIO,bool ShowFileName,
                  wchar Command);

#endif
