#define INCLUDEGLOBAL

#ifdef _MSC_VER
#pragma hdrstop
#endif

#include "rar.hpp"
